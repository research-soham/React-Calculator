import logo from './logo.svg';
import './App.css';
import Number from './Number';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        < Number />
       
        <p>
          Soham Baghela
        </p>
        <a
          className="App-link"
          href="https://instagram.com/_100_we?igshid=OGQ5ZDc2ODk2ZA=="
          target="_blank"
          rel="noopener noreferrer"
        >
          Instagram
        </a>
      </header>
    </div>
  );
}

export default App;
