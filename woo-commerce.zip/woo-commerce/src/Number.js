import { useState } from "react";

function Number() {
    const [value, setValue] = useState('');
    const [displayCleared, setDisplayCleared] = useState(true);
    const [displayDefault, setDisplayDefault] = useState(true);
    const handleButtonPress = (button) => {
      setValue(value + button);
      setDisplayCleared(true);
      console.log(displayCleared)
    }

    function clearScreen(){
      setValue('');
      setDisplayCleared(false);
      console.log(displayCleared)
    }

    function handleCalculation(){
      setValue(eval(value))
    }

    return (
      <div className="calculator">
        <input type="text" value={value} className="display" style={{ backgroundColor: displayCleared ? '#a03f3f' : displayDefault ? '#441f1f' : 'gray', border: "black" }} />
        <div className="buttons">
          <button onClick={() => handleButtonPress('1')}>1</button>
          <button onClick={() => handleButtonPress('2')}>2</button>
          <button onClick={() => handleButtonPress('3')}>3</button>
          <button onClick={() => clearScreen()}>C</button>
          <button onClick={() => handleButtonPress('4')}>4</button>
          <button onClick={() => handleButtonPress('5')}>5</button>
          <button onClick={() => handleButtonPress('6')}>6</button>
          <button onClick={() => handleButtonPress('+')}>+</button>
          <button onClick={() => handleButtonPress('7')}>7</button>
          <button onClick={() => handleButtonPress('8')}>8</button>
          <button onClick={() => handleButtonPress('9')}>9</button>
          <button onClick={() => handleButtonPress('-')}>-</button>
          <button onClick={() => handleButtonPress('/')}>÷</button>
          <button onClick={() => handleButtonPress('0')}>0</button>
          <button onClick={() => handleButtonPress('*')}>*</button>
          <button onClick={() => handleCalculation()}>=</button>
        </div>
      </div>
    );
}

export default Number;
